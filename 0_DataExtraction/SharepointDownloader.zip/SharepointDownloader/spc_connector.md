# Sharepoint API Connector Documentation

This document provides documentation for the Sharepoint API Connector code, which interacts with the Microsoft Graph API to perform various operations on Sharepoint resources.

## Setup

### Setting Permissions for Azure APP

To ensure a proper run of the code, it is needed to set the permissions to your team's Azure APP.

Use your administrator permission to make a post request in order to set the correct permission. *<b>If you do not have administrator permission, you won't be allowed to the this permission*</b>.

Useful Guides:
- [Configuring Permissions](https://www.youtube.com/watch?v=rK4OWwXfEWE)
- [Microsoft Documentation](https://learn.microsoft.com/en-us/graph/api/site-post-permissions?view=graph-rest-1.0&tabs=http)

API Explorer (for a faster and better post request to set permission, as settle in the video above)
- [Microsoft Graph API Explorer](https://developer.microsoft.com/en-us/graph/graph-explorer)

## Prerequisites

To run this code, you'll need:

- Python 3.x installed
- Python packages listed in `requirements.txt`
- An application registered in Azure Active Directory with permissions to access Microsoft Graph API

## Features

### 1. SharepointDownloader Class

The `SharepointDownloader` class encapsulates the logic for authentication and interaction with Graph API.

#### Methods:

- `__init__()`: Initializes the class and loads environment variables.
- `get_token()`: Obtains an access token for authentication.
- `get_response_id(result_json, match)`: Parses API response and returns the ID of an item matching the provided name.
- `get_drive_id()`: Gets the SharePoint drive ID and root folder ID.
- `find_file(drive_id, folder_id, target_file_name, headers)`: Locates the ID of a specific file within a folder structure.
- `download_file(target_file_name)`: Downloads the specified file from SharePoint.

### 2. Utility Methods

- `load_dotenv()`: Loads environment variables from the `.env` file.
- `urlretrieve()`: Downloads the file from the provided URL.

## How to Use

1. Set the environment variables `CLIENT_ID`, `CLIENT_SECRET`, `TENANT_ID`, and `SHAREPOINT_SITE_ID`.
2. Instantiate the `SharepointDownloader` class.
3. Call the `download_file()` method with the desired file name.

Example:
```python
sharepoint_downloader = SharepointDownloader()
sharepoint_downloader.download_file(target_file_name="DataLAB Line Inspector.xlsx")