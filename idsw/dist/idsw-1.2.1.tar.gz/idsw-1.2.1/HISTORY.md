# History

## 1.2.0
### Fixed
- Deprecated structures

### Added
- New functionalities added.

### Reshape of project design.
- New division into modules and new names for functions and classes.

### Removed
- Removed support for Python < 3.7

## 1.2.1
### Fixed
- Setup issues.