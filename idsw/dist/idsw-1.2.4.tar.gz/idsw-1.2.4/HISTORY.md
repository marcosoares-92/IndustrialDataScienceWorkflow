# History

## 1.2.0
### Fixed
- Deprecated structures

### Added
- New functionalities added.

### Reshape of project design.
- New division into modules and new names for functions and classes.

### Removed
- Removed support for Python < 3.7

## 1.2.1
### Fixed
- Setup issues.

## 1.2.2
### Fixed
- Setup issues: need for rigid and specific versions of the libraries.

## 1.2.3
### Fixed
- Setup issues.

## 1.2.4
### Fixed
- Import bugs.
- Introduced function for Excel writing.